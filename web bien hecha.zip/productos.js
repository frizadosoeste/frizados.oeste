/* =====================================================================
   PRODUCTOS.JS — todo lo que se edita seguido está en este archivo.
   - CONFIG: nombre de la marca, WhatsApp, Instagram, horarios y envíos.
   - CATEGORIAS: tarjetas de categorías (activa: false = "Muy pronto").
   - PRODUCTOS: cada producto es un bloque { ... }. Para agregar uno,
     copiá un bloque entero, pegalo abajo y cambiá los datos.
   Precios: número sin puntos de miles, decimales con punto (1111.11).
   ===================================================================== */

window.CONFIG = {
  marca: "Frizá",                       // ← nombre de la marca
  ciudad: "Río Cuarto, Córdoba",
  whatsapp: "5493584244734",            // ← 549 + característica sin 0 + número sin 15
  whatsappVisible: "+54 9 358 424-4734",      // ← cómo se muestra el número en la web
  instagram: "frizados.oeste",          // ← usuario de Instagram sin @
  entregas: "Sábados",                  // ← día(s) de entrega
  entregasHorario: "Horario a coordinar por WhatsApp", // ← ej: "10 a 14 h"
  horarios: [                           // ← días y horarios de atención (para tomar pedidos)
    { dias: "Lunes a viernes", horas: "9 a 13 y 17 a 21 h" },
    { dias: "Sábados", horas: "9 a 14 h" }
  ],
  envios: [                             // ← zonas, costo y días de entrega
    { zona: "Centro y macrocentro", costo: "A confirmar", entrega: "Sábados" },
    { zona: "Banda Norte", costo: "A confirmar", entrega: "Sábados" },
    { zona: "Barrios periféricos", costo: "A confirmar", entrega: "Sábados" }
  ],
  pedidoMinimo: "",                     // ← ej: "$ 20.000" (vacío = no se muestra)
  envioGratisDesde: ""                  // ← ej: "$ 60.000" (vacío = no se muestra)
};

window.CATEGORIAS = [
  { id: "hamburguesas", nombre: "Hamburguesas", texto: "Para la plancha o la parrilla", activa: true },
  { id: "papas",        nombre: "Papas y acompañamientos", texto: "Bastón, noisette, caritas y aros", activa: true },
  { id: "helados",      nombre: "Helados", texto: "Baldes de 3 L y palitos Aloha", activa: true },
  { id: "milanesas",    nombre: "Milanesas", texto: "Carne, pollo y soja", activa: false },
  { id: "pastas",       nombre: "Pastas", texto: "Ñoquis, ravioles y sorrentinos", activa: false },
  { id: "pizzas",       nombre: "Pizzas", texto: "Prepizzas y pizzas listas", activa: false },
  { id: "empanadas",    nombre: "Empanadas", texto: "Al horno o fritas", activa: false },
  { id: "verduras",     nombre: "Verduras", texto: "Congeladas y listas para usar", activa: false },
  { id: "listos",       nombre: "Listos para cocinar", texto: "Del freezer al horno", activa: false }
];

/* Fotos: se guardan en la carpeta img/ y se nombran en "imagen".
   bulto: null si no se vende por bulto. destacado: true lo muestra primero. */
window.PRODUCTOS = [
  {
    id: "hamburguesa-clasica",
    nombre: "Hamburguesa Clásica",
    marca: "Unión Ganadera",
    categoria: "hamburguesas",
    descripcion: "Carne vacuna, lista para la plancha o la parrilla. De la caja al pan en minutos.",
    presentacion: "Unidad 83 g",
    precio: 2300,
    unidad: "c/u",
    bulto: { texto: "60 u", precio: 138000 },
    imagen: "img/hamburguesa-clasica.jpg",
    destacado: true
  },
  {
    id: "balde-marron",
    nombre: "Balde Marrón",
    marca: "Aloha",
    categoria: "helados",
    descripcion: "Chocolate, vainilla, dulce de leche y granizado. Postre para toda la familia.",
    presentacion: "Balde 3 L · CH-V-DL-GR",
    precio: 20000,
    unidad: "c/u",
    bulto: null,
    imagen: "img/balde-marron.jpg",
    destacado: true
  },
  {
    id: "balde-amarillo",
    nombre: "Balde Amarillo",
    marca: "Aloha",
    categoria: "helados",
    descripcion: "Banana split, dulce de leche, vainilla y tiramisú.",
    presentacion: "Balde 3 L · BS-DL-V-TIR",
    precio: 20000,
    unidad: "c/u",
    bulto: null,
    imagen: "img/balde-amarillo.jpg",
    destacado: false
  },
  {
    id: "balde-rojo",
    nombre: "Balde Rojo",
    marca: "Aloha",
    categoria: "helados",
    descripcion: "Dulce de leche granizado, chocolate, americana y frutilla.",
    presentacion: "Balde 3 L · DLG-CH-AM-FR",
    precio: 20000,
    unidad: "c/u",
    bulto: null,
    imagen: "img/balde-rojo.jpg",
    destacado: false
  },
  {
    id: "balde-verde",
    nombre: "Balde Verde",
    marca: "Aloha",
    categoria: "helados",
    descripcion: "Frutilla, dulce de leche, vainilla y tramontana.",
    presentacion: "Balde 3 L · FR-DL-V-TRM",
    precio: 20000,
    unidad: "c/u",
    bulto: null,
    imagen: "img/balde-verde.jpg",
    destacado: false
  },
  {
    id: "bombon-escoces-blanco",
    nombre: "Bombón Escocés Blanco",
    marca: "Aloha",
    categoria: "helados",
    descripcion: "El postre clásico, listo para servir.",
    presentacion: "Unidad 85 g",
    precio: 2956.25,
    unidad: "c/u",
    bulto: { texto: "16 u x 85 g", precio: 47300 },
    imagen: "img/bombon-escoces-blanco.jpg",
    destacado: false
  },
  {
    id: "bombon-escoces-negro",
    nombre: "Bombón Escocés Negro",
    marca: "Aloha",
    categoria: "helados",
    descripcion: "Bañado en chocolate con corazón de dulce de leche.",
    presentacion: "Unidad 85 g",
    precio: 2956.25,
    unidad: "c/u",
    bulto: { texto: "16 u x 85 g", precio: 47300 },
    imagen: "img/bombon-escoces-negro.jpg",
    destacado: true
  },
  {
    id: "cremissimo-dulce-de-leche",
    nombre: "Cremissimo Dulce de Leche",
    marca: "Aloha",
    categoria: "helados",
    descripcion: "Helado de dulce de leche bañado en chocolate.",
    presentacion: "Unidad 60 cc",
    precio: 1751.85,
    unidad: "c/u",
    bulto: { texto: "27 u x 60 cc", precio: 47300 },
    imagen: "img/cremissimo-dulce-de-leche.jpg",
    destacado: false
  },
  {
    id: "cremissimo-chocolate",
    nombre: "Cremissimo Chocolate",
    marca: "Aloha",
    categoria: "helados",
    descripcion: "Crema de chocolate bañada en chocolate.",
    presentacion: "Unidad 60 cc",
    precio: 1751.85,
    unidad: "c/u",
    bulto: { texto: "27 u x 60 cc", precio: 47300 },
    imagen: "img/cremissimo-chocolate.jpg",
    destacado: false
  },
  {
    id: "granibon",
    nombre: "Granibon",
    marca: "Aloha",
    categoria: "helados",
    descripcion: "Crema con granizado y baño crocante.",
    presentacion: "Unidad 80 cc",
    precio: 1729.17,
    unidad: "c/u",
    bulto: { texto: "24 u x 80 cc", precio: 41500 },
    imagen: "img/granibon.jpg",
    destacado: false
  },
  {
    id: "palito-bombon",
    nombre: "Palito Bombón",
    marca: "Aloha",
    categoria: "helados",
    descripcion: "Vainilla bañada en chocolate. El de siempre.",
    presentacion: "Unidad 60 cc",
    precio: 2185.19,
    unidad: "c/u",
    bulto: { texto: "27 u x 60 cc", precio: 59000 },
    imagen: "img/palito-bombon.jpg",
    destacado: true
  },
  {
    id: "surfy-frutilla",
    nombre: "Surfy Frutilla",
    marca: "Aloha",
    categoria: "helados",
    descripcion: "Palito de agua sabor frutilla, bien refrescante.",
    presentacion: "Unidad 50 cc",
    precio: 1111.11,
    unidad: "c/u",
    bulto: { texto: "36 u x 50 cc", precio: 40000 },
    imagen: "img/surfy-frutilla.jpg",
    destacado: false
  },
  {
    id: "surfy-naranja-mango",
    nombre: "Surfy Naranja-Mango",
    marca: "Aloha",
    categoria: "helados",
    descripcion: "Palito de agua sabor naranja y mango.",
    presentacion: "Unidad 50 cc",
    precio: 1111.11,
    unidad: "c/u",
    bulto: { texto: "36 u x 50 cc", precio: 40000 },
    imagen: "img/surfy-naranja-mango.jpg",
    destacado: false
  },
  {
    id: "surfy-limon",
    nombre: "Surfy Limón",
    marca: "Aloha",
    categoria: "helados",
    descripcion: "Palito de agua sabor limón.",
    presentacion: "Unidad 50 cc",
    precio: 1111.11,
    unidad: "c/u",
    bulto: { texto: "36 u x 50 cc", precio: 40000 },
    imagen: "img/surfy-limon.jpg",
    destacado: false
  },
  {
    id: "surfy-chicle-globo",
    nombre: "Surfy Chicle Globo",
    marca: "Aloha",
    categoria: "helados",
    descripcion: "Palito de agua sabor chicle. El favorito de los chicos.",
    presentacion: "Unidad 50 cc",
    precio: 1111.11,
    unidad: "c/u",
    bulto: { texto: "36 u x 50 cc", precio: 40000 },
    imagen: "img/surfy-chicle-globo.jpg",
    destacado: false
  },
  {
    id: "alfajor-dulce-de-leche-black",
    nombre: "Alfajor Dulce de Leche Black",
    marca: "Aloha",
    categoria: "helados",
    descripcion: "Alfajor helado de dulce de leche bañado en chocolate.",
    presentacion: "Unidad 80 g",
    precio: 2500,
    unidad: "c/u",
    bulto: { texto: "18 u x 80 g", precio: 45000 },
    imagen: "img/alfajor-dulce-de-leche-black.jpg",
    destacado: false
  },
  {
    id: "maxui-pistacho",
    nombre: "Maxui Pistacho",
    marca: "Aloha",
    categoria: "helados",
    descripcion: "Helado de pistacho bañado.",
    presentacion: "Unidad 100 cc",
    precio: 2875,
    unidad: "c/u",
    bulto: { texto: "16 u x 100 cc", precio: 46000 },
    imagen: "img/maxui-pistacho.jpg",
    destacado: true
  },
  {
    id: "papa-stealth-fries-9-mm",
    nombre: "Papa Stealth Fries 9 mm",
    marca: "Lamb Weston",
    categoria: "papas",
    descripcion: "Papas bastón que quedan crocantes por más tiempo. Rinden un montón.",
    presentacion: "Bolsa 2,5 kg",
    precio: 15833.33,
    unidad: "la bolsa",
    bulto: { texto: "6 bolsas x 2,5 kg", precio: 95000 },
    imagen: "img/papa-stealth-fries-9-mm.jpg",
    destacado: true
  },
  {
    id: "papas-noisette",
    nombre: "Papas Noisette",
    marca: "BEM Brasil",
    categoria: "papas",
    descripcion: "Bolitas de papa doradas. Al horno, freidora o air fryer.",
    presentacion: "Bolsa 1,05 kg",
    precio: 7500,
    unidad: "la bolsa",
    bulto: { texto: "10 bolsas x 1,05 kg", precio: 75000 },
    imagen: "img/papas-noisette.jpg",
    destacado: true
  },
  {
    id: "papa-carita",
    nombre: "Papa Carita",
    marca: "BEM Brasil",
    categoria: "papas",
    descripcion: "Papas con forma de carita. Las que piden los chicos.",
    presentacion: "Bolsa 1,05 kg",
    precio: 7500,
    unidad: "la bolsa",
    bulto: { texto: "10 bolsas x 1,05 kg", precio: 75000 },
    imagen: "img/papa-carita.jpg",
    destacado: false
  },
  {
    id: "aros-de-cebolla",
    nombre: "Aros de Cebolla",
    marca: "BEM Brasil",
    categoria: "papas",
    descripcion: "Aros rebozados y crocantes, ideales para picar.",
    presentacion: "Bolsa 1,05 kg",
    precio: 9375,
    unidad: "la bolsa",
    bulto: { texto: "8 bolsas x 1,05 kg", precio: 75000 },
    imagen: "img/aros-de-cebolla.jpg",
    destacado: true
  }
];
